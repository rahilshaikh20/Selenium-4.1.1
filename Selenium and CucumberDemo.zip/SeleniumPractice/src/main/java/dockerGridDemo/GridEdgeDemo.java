package dockerGridDemo;

import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GridEdgeDemo {
	
	@Test
	public void ChromeTest() throws MalformedURLException, InterruptedException
	{
		// ****To check status is Selenium 4 :http://localhost:4546/status
		//Code for Selenium 4 
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new RemoteWebDriver(new URL("http://192.168.0.100:4444"), new EdgeOptions()); 
		
		driver.get("https://www.youtube.com/");
		System.out.println(driver.getTitle());
		
		Thread.sleep(8000);
		
		driver.quit();
		
	}

}
