package excelDataReader;


import org.testng.annotations.Test;

public class ExcelExample
{

	@Test(dataProvider = "dataFromExcel" , dataProviderClass = DataProviderClass.class)
	public void demoClass(String username, String password, String add) throws InterruptedException
	{
		System.out.println("User is "+username);
		System.out.println("Pass is "+password);
		System.out.println("Address is "+add);
		System.out.println();
	}

}
