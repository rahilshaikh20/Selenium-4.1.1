package excelDataReader;

public class DataProviderClass {

	@org.testng.annotations.DataProvider
	public Object[][] dataFromExcel() 
	{
		ExcelReader configuration = new ExcelReader("C:\\Selenium Projects\\Sample.xlsx");
		int rows = configuration.getRowCount(0);

		Object[][] DataFromExcel = new Object[rows - 1][3];//Assuming first row is Data type and not required

		for (int i = 0; i < rows - 1; i++) 
		{

			DataFromExcel[i][0] = configuration.getData(0, i + 1, 0);
			DataFromExcel[i][1] = configuration.getData(0, i + 1, 1);
			DataFromExcel[i][2] = configuration.getData(0, i + 1, 2);
		}
		return DataFromExcel;

	}
}
