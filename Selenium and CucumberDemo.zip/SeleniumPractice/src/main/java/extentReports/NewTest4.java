package extentReports;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

class NewTest4 extends ExtReportDemo {

	WebDriver driver;

	@BeforeClass
	public void Before() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}

	@Test
	public void TC_001() throws InterruptedException {
		test = extent.createTest("TC_001_Guru99Test");
		test.log(Status.INFO, "Info logged in report");

		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://www.guru99.com/using-contains-sbiling-ancestor-to-find-element-in-selenium.html");
		System.out.println(driver.getWindowHandle());
		System.out.println(driver.getTitle());
		Assert.assertTrue(false);

		Thread.sleep(3000);


	}

	@AfterClass
	public void TearDown() 
	{
		driver.quit();

	}
}
