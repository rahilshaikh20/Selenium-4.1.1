package extentReports;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

class NewTest3 extends ExtReportDemo {

	WebDriver driver;

	@BeforeClass
	public void Before() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	}

	@Test
	public void TC_003() throws InterruptedException {
		test = extent.createTest("TC_003_YoutubeTest");
		test.log(Status.INFO, "Info logged in report");

		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://www.youtube.com/");
		System.out.println(driver.getWindowHandle());
		System.out.println(driver.getTitle());

		Thread.sleep(3000);


	}

	@AfterClass
	public void TearDown() 
	{
		driver.quit();

	}
}
