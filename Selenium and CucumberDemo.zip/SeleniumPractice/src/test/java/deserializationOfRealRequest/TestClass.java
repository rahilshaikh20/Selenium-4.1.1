package deserializationOfRealRequest;
import java.util.List;

import org.testng.annotations.Test;
import io.restassured.RestAssured;

public class TestClass {
	
	@Test
	public void RunDesrializationTest()
	{		
		RestAssured.baseURI = "https://reqres.in";
		ListUsersPOJO obj= RestAssured.given().queryParam("page","2").get("/api/users").as(ListUsersPOJO.class);
		
		System.out.println(obj.toString());
		
		List<DataPOJO> list = obj.getData();
		
		for (DataPOJO dataPOJO : list) {
			
		System.out.println("ID is "+dataPOJO.getId());	
		System.out.println("Email is "+dataPOJO.getEmail());
		System.out.println("F_Name is "+dataPOJO.getFirst_name());
		System.out.println("L_Name is "+dataPOJO.getLast_name());	
		System.out.println("Avatar is "+dataPOJO.getAvatar());
		System.out.println();
		}
		
	}
}
