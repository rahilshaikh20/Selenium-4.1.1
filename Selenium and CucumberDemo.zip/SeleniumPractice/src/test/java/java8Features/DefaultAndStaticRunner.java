package java8Features;

public class DefaultAndStaticRunner implements DefaultAndStaticMethods {

	@Override
	public void RegularAbstractMethod() {
		System.out.println("RegularAbstractMethod implemented");

	}
	
	public  void DefaultMethod()
	{
		System.out.println("Default Method overridden by Child Class");
	}
	

	public static void main(String[] args) {

		DefaultAndStaticMethods obj = new DefaultAndStaticRunner();

		obj.DefaultMethod(); // Calling Default method
		obj.RegularAbstractMethod(); // Calling implementation of Abstract method
		DefaultAndStaticMethods.StaticMethod();// Calling Static method

	}

}
