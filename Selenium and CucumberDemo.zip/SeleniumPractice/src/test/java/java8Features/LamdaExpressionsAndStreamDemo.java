package java8Features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LamdaExpressionsAndStreamDemo {
	
	public static void main(String[] args) {
		
		List <Integer> numVal =Arrays.asList(1,2,4,78,99,34,56);
		
		numVal.forEach(i-> System.out.println("Values in array "+i));
		numVal.forEach(System.out::println);
		
		//Stream
		System.out.println("\nParallel Stream started:");
		numVal.parallelStream().forEach(System.out::println);
		
		
		List <Integer> values = new ArrayList<Integer>();
		for(int i=0; i<9;i++)
		{
			values.add(i);
		}
			
		
		values.stream().filter(i->{System.out.println("hi");
		return true;
		});
			
	}

}
