package java8Features;

import java.util.function.Consumer;

class ConsumerInterfaceDemo implements Consumer<String> {

	public void accept(String e) 
	{
		System.out.println("Sring input is " + e);
	}

}
