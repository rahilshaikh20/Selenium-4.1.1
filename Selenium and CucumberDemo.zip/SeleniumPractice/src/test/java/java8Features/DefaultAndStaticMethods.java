package java8Features;

public interface DefaultAndStaticMethods {
	
	default void DefaultMethod()
	{
		System.out.println("Default Method from Parent Interface");
	}
	
	static void StaticMethod()
	{
		System.out.println("This is Static Method");
	}
	
	public void RegularAbstractMethod();

}
