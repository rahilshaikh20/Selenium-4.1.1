package java8Features;

import java.util.function.Consumer;

public class ConsumerRunner {

	public static void main(String[] args) {
				
		 Consumer<String> obj = new ConsumerInterfaceDemo();
		 obj.accept("Rahil");
		 
		 obj=(String s)->{System.out.println("END");};

	}

}
