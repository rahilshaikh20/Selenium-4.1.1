package java8Features;

interface A 
{
	void show();
}

interface B 
{
	void show(int i, String s);
}

public class FunctionalInterfaceDemo {
	
	public static void main(String[] args) {
		
		A obj;
		obj =new A()// Anonymous inner class
				{
				public void show()
				{
					System.out.println("Show printed");
				}
				};
		
		obj.show();
		
		//Using lambda expressions without params
		A obj1;
		obj1= ()->{System.out.println("Show with Lamba printed");};
		obj1.show();
		
		//Using lambda expressions with params
				B obj2;
				obj2= (i,s)->{System.out.println("Int val are "+i+" and "+"String val is "+s);};
				obj2.show(25, "Rahil");
		
	}

}
