package createCustomExceptions;

public class CloneExceptions implements Cloneable{
	
	 private String name;
	 
	    public CloneExceptions(String name)
	    {
	        super();
	        this.name = name;
	    }
	    
	    
	    public static void main(String[] args) throws CloneNotSupportedException {
	    	
	    	try {
			
	    	CloneExceptions obj1= new CloneExceptions("Rahil");
	    	CloneExceptions obj2= (CloneExceptions) obj1.clone();
	    	
	    	System.out.println(obj2.name);
	    	}
	    	catch (CloneNotSupportedException a)
	    	{
	    		a.printStackTrace();
	    	}
	    	
	    	
		}

}
