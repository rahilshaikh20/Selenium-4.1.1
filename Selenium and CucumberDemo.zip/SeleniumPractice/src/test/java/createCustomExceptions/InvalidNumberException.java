package createCustomExceptions;

public class InvalidNumberException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidNumberException() {
		super("The Number Entered is Invalid! ");
	}

	public InvalidNumberException(String message) {
		super(message);
	}

}
