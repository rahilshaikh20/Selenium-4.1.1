package createCustomExceptions;

public class EnterNumberRunner {
	

	public static void main(String[] args) {

		int i=19;
				
		try 
		{			
			if(i<10)
			System.out.println("Number accepted");	
			
			else
			throw new InvalidNumberException("Hey! Enter number less than 10");	
				
		} 
		catch (InvalidNumberException e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
