package comparableAndComparator;

import java.util.Comparator;

public class NameComparator implements Comparator<MovieComparable> 
{

	public int compare(MovieComparable m1, MovieComparable m2) 
	{
		return m1.getName().compareTo(m2.getName());
	}

}

