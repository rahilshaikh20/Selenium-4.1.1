package comparableAndComparator;

import java.util.ArrayList;
import java.util.Collections;

public class ComparatorRunner {
	
	
	 public static void main(String[] args)
	    {
	        ArrayList<MovieComparable> list = new ArrayList<MovieComparable>();
	        list.add(new MovieComparable("Thursday", 8.2, 2022));
	        list.add(new MovieComparable("Game of Thrones", 8.1, 2012));
	        list.add(new MovieComparable("Rear Window", 8.9, 1960));
	        list.add(new MovieComparable("Shawshank", 9.4, 1991));
	 
	        // Sort by rating : (1) Create an object of ratingCompare
	        //                  (2) Call Collections.sort
	        //                  (3) Print Sorted list
	        System.out.println("****Sorted by rating****");
	        RatingComparator ratingCompare = new RatingComparator();
	        Collections.sort(list, ratingCompare);
	       
	       System.out.println(list);
	 
	 
	        // Call overloaded sort method with RatingCompare
	        // (Same three steps as above)
	        System.out.println("\n****Sorted by name*****");
	        NameComparator nameCompare = new NameComparator();
	        Collections.sort(list, nameCompare);
	        System.out.println(list);
	 
	

}}
