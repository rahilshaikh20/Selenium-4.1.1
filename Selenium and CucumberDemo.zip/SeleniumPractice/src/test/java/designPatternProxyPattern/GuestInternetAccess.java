package designPatternProxyPattern;

public class GuestInternetAccess extends InternetAccess {

	@Override
	void provideInternetAccess() {
		// TODO Auto-generated method stub
		System.out.println("Guest Internet Access provided to Employee");
	}
		

}
