package designPatternProxyPattern;

public abstract class InternetAccess {
	
	abstract void provideInternetAccess();

}
