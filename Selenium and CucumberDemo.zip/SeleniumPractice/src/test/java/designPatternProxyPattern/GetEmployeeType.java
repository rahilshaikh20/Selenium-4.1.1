package designPatternProxyPattern;

public class GetEmployeeType {

	public static void main(String[] args) {
		InternetAccess obj = null;

		int EmployeeLevel = 7; // Get the employee level to decide the type of access

		if (EmployeeLevel > 5)
			obj = new CompanyInternetAccess();
		else
			obj = new GuestInternetAccess();

		obj.provideInternetAccess();

	}

}
