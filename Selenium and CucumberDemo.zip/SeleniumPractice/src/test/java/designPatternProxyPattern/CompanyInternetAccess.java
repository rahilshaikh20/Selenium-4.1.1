package designPatternProxyPattern;

public class CompanyInternetAccess extends InternetAccess {

	@Override
	void provideInternetAccess() {
		// TODO Auto-generated method stub
		System.out.println("Company Internet Access provided to Employee");
	}

}
