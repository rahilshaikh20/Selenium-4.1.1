
public class SettersGetters {

	private String name;
	private int age;
	private String address;
	private float experience;

	SettersGetters(String N, int a, String ad, float exp) {
		name = N;
		age = a;
		address = ad;
		experience = exp;
	}
	SettersGetters()
	{
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public float getExperience() {
		return experience;
	}

	public void setExperience(float d) {
		this.experience = d;
	}

}
