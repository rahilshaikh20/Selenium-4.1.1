package designPatternTemplatePattern;

public class Football extends Game {

	@Override
	void initializeGame() {
		// TODO Auto-generated method stub
		System.out.println("Football Initialized");

	}

	@Override
	void startGame() {
		// TODO Auto-generated method stub
		System.out.println("Football Started");
	}

	@Override
	void endGame() {
		// TODO Auto-generated method stub
		System.out.println("Football Ended");

	}

}
