package designPatternTemplatePattern;

public class GameLauncher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game game = new Football();
		game.run();
		
		System.out.println();
		
		game=new Cricket();
		game.run();

	}

}
