package designPatternTemplatePattern;

public abstract class Game {
	
	abstract void initializeGame();
	abstract void startGame();
	abstract void endGame();
	
	public void run()
	{
		initializeGame();
		startGame();
		endGame();
	}

}
