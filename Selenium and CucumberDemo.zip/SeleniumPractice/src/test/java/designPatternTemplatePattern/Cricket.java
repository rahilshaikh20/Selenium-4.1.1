package designPatternTemplatePattern;

public class Cricket extends Game {

	@Override
	void initializeGame() {
		// TODO Auto-generated method stub
		System.out.println("Cricket Initialized");

	}

	@Override
	void startGame() {
		// TODO Auto-generated method stub
		System.out.println("Cricket Started");

	}

	@Override
	void endGame() {
		// TODO Auto-generated method stub
		System.out.println("Cricket Ended");

	}

}
