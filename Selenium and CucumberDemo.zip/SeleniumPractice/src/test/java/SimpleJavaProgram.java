
public class SimpleJavaProgram {


	static String s = "Rahil";
	static int i = 8;
	static int count =0;
	

	public SimpleJavaProgram() {
		
		count++;
	}

	static {
		System.out.println("Static int val = "+i);
		System.out.println("Static String val = "+s);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Hello!!!!");
				
		SimpleJavaProgram obj1 = new SimpleJavaProgram();
		SimpleJavaProgram obj2 = new SimpleJavaProgram();
		
		System.out.println("Objects count is = "+count);

	}

}
