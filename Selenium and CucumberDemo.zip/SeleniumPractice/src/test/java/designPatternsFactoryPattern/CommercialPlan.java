package designPatternsFactoryPattern;

public class CommercialPlan extends Plan {

	@Override
	void getRate() {
		// TODO Auto-generated method stub
		rate =7.5;
		
	}
	

}
