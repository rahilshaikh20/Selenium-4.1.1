package designPatternsFactoryPattern;

public class GenerateBill {

	public static void main(String[] args) {

		String planType = "COMMERCIALPLAN"; // Getting the PlanType from the user
		int unit = 100;// Units consumed

		GetPlanType plan = new GetPlanType();
		Plan p = plan.getPlan(planType);// Will create an object of Domestic or Commercial on basis of plan type
		
		
		p.getRate(); //Will get the Domestic or Commercial rate
		p.calculateBill(unit);

	}

}
