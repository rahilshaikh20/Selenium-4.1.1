package designPatternsFactoryPattern;

//Factory pattern

abstract class Plan {

	protected double rate;

	abstract void getRate();

	public void calculateBill(int units)
	{
		System.out.println("Total Bill amount is: "+units * rate);
	}

}
