import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class NewTest {
  @Test(dataProvider = "dp")
  public void f(Integer n, String s) {
	  
	  System.out.println("String value is "+s);
	  System.out.println("Numeric value is "+n);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 1, "a" },
      new Object[] { 2, "b" },
    };
  }
  @AfterClass
  public void afterClass() {
	  
	  System.out.println("***After class executed***");
  }

  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("***Before Suite executed***");
  }

  @AfterSuite
  public void afterSuite() {
	  System.out.println("***After Suite executed***");
  }

}
