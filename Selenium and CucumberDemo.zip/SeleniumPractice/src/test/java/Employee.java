import java.util.ArrayList;
import java.util.List;

public class Employee {

	public static void main(String[] args) {

		List<SettersGetters> list = new ArrayList<SettersGetters>();

		SettersGetters obj = new SettersGetters();

		obj.setName("Rahil");
		obj.setAddress("Malad");
		obj.setAge(34);
		obj.setExperience(11);

		System.out.println("Name is " + obj.getName());
		System.out.println("Address is " + obj.getAddress());
		System.out.println("Age is " + obj.getAge());
		System.out.println("Experience is " + obj.getExperience() + "\n");

		list.add(new SettersGetters("Shahla", 31, "Mira road", 7));
		list.add(new SettersGetters("Samreen", 30, "Kharghar", 6));

		for (int i = 0; i < list.size(); i++) {
			System.out.println("Name is " + list.get(i).getName());
			System.out.println("Address is " + list.get(i).getAddress());
			System.out.println("Age is " + list.get(i).getAge());
			System.out.println("Experience is " + list.get(i).getExperience());
			System.out.println();

		}

		System.out.println("***printing using for each***\n");
		for (SettersGetters settersGetters : list) {

			System.out.println(settersGetters.getAddress());
			System.out.println(settersGetters.getName());

		}

		System.out.println("***printing using lambda exp***\n");
		list.forEach(i -> System.out
				.println(i.getName() + "," + i.getAddress() + "," + i.getAge() + "," + i.getExperience()));
	}

}
