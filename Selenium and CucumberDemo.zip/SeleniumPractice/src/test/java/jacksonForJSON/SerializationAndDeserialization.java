package jacksonForJSON;
import java.io.File;
import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SerializationAndDeserialization {

	public static void main(String[] args) throws JsonProcessingException, IOException, IOException {
		//Serialization
		
		  EmployeeRecord emp = new EmployeeRecord("Rahil", 34, 40000); 
		  ObjectMapper mapper = new ObjectMapper();
		  
		  mapper.writeValue(new File("SampleMapper.json"), emp);
		  System.out.println("Serialization completed");
		 
		
		//Deserialization using JSON file
		
		EmployeeRecord emp1 = mapper.readValue(new File("SampleMapper.json"), EmployeeRecord.class);
		System.out.println("Name is "+emp1.getName());
		System.out.println("Age is "+emp1.getAge());
		System.out.println("Salary is "+emp1.getSalary());
	
		//Deserialization using JSON String
		String JSONdata = "{\"name\":\"Samreen\",\"age\":31,\"salary\":60000.0}";
		EmployeeRecord emp2=mapper.readValue(JSONdata, EmployeeRecord.class);
		
		System.out.println();
		System.out.println("Name is "+emp2.getName());
		System.out.println("Age is "+emp2.getAge());
		System.out.println("Salary is "+emp2.getSalary());
		
		
		//Deserialization using JSON Node
		JsonNode node = mapper.readTree(JSONdata);
		
		String EmpName = node.get("name").asText();
		int age = node.get("age").asInt();
		
		System.out.println("Name retrived from node: "+EmpName);
		System.out.println("Age retrived from node: "+age);
		
		System.out.println("*****Deserialization completed*****");
		
		//Deserialization to list of Objects
		List <EmployeeRecord> empList =mapper.readValue(new File("C:\\Users\\Rahil_Shaikh\\Documents\\EPAM\\SampleMapperList.json"), 
				new TypeReference<List<EmployeeRecord>>(){});	
		
		for (EmployeeRecord employeeRecord : empList) {
			
			System.out.println("Name is "+ employeeRecord.getName());
			System.out.println("Age is "+ employeeRecord.getAge());
		}
		
	}

}
