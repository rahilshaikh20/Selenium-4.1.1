package jacksonForJSON;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequest {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://reqres.in";

		RequestSpecification httpRequest = RestAssured.given();//set 

		Response response = httpRequest.queryParam("page","1").get("/api/users");
		response.prettyPrint();

		int responseStatus = response.statusCode();
		System.out.println("Status is: "+responseStatus);
	}

}
