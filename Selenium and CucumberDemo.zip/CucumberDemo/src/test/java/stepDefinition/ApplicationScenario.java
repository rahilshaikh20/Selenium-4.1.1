package stepDefinition;



import io.cucumber.java.en.*;

public class ApplicationScenario {
	

@Given("^login to the application$")
public void login_to_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Logged in application");
    
}

@When("^enter \"([^\"]*)\" and  \"([^\"]*)\"$")
public void enter_and(String arg1, String arg2) throws Throwable {
	
	System.out.println("Name is: "+ arg1);
	System.out.println("Password is: "+ arg2);
    // Write code here that turns the phrase above into concrete actions

}

@When("^User enters \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
public void user_enters_and_and(String arg1, String arg2, String arg3) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("Age retrived is: "+ arg1);
	System.out.println("Class retrived is: "+ arg2);
	System.out.println("Type retrived is: "+ arg3);
  
}

@When("^verify the login$")
public void verify_the_login() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
       
    System.out.println("Login Verified****");
}


}
