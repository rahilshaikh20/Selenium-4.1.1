package stepDefinition;

import io.cucumber.java.en.*;
import junit.framework.Assert;

public class CRMFlow {
	
	@Given("^CRM application is logged in$")
	public void crm_application_is_logged_in() throws Throwable {
		System.out.println("***LOGGED IN CRM****");
	}

	@When("^User creates a customer$")
	public void user_creates_a_customer() throws Throwable {
		System.out.println("***CUSTOMER CREATED IN CRM****");
		//Assert.assertTrue(false);
	}

	@When("^User provides the documents$")
	public void user_provides_the_documents() throws Throwable {
		System.out.println("***DOCS UPLOADED IN CRM****");
	
	}

	@Then("^User can see it's information updated$")
	public void user_can_see_it_s_information_updated() throws Throwable {
		System.out.println("***INFO UPDATED IN CRM AND USER CAN VIEW IT****");
	}



}
