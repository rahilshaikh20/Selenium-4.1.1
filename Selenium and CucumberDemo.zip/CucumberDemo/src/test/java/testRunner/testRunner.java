package testRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(
		stepNotifications = true, 
		strict = true,
		features = { "Feature" },
		glue = { "stepDefinition" }, 
		tags = "@crm", 
		plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
		monochrome = true

)
public class testRunner {
	
}
